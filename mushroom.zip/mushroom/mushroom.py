import os

path=os.path.dirname(os.path.abspath(__file__))

with open (path+"\\directory.txt", "r") as a:
	directorylist= a.readlines()
	directorylist = [line.rstrip() for line in directorylist]

a.close
if directorylist[-1]=="openedOnce=FALSE":
	with open(path+"\\directory.txt", "w") as a:
		a.write(path+"\\functions.txt""\n"+path+"\\keywords.txt")
	a.close
import mushroom_script
import pyperclip

while True:
	print("")
	print("█▀▄▀█ █ █ █▀ █ █ █▀█ █▀█ █▀█ █▀▄▀█")
	print("█ ▀ █ █▄█ ▄█ █▀█ █▀▄ █▄█ █▄█ █ ▀ █")
	print("version 2.0")
	print("")
	print("by kberkboz")
	print("Spread the spores!")
	
	


	while True:

		text = input('mushroom > ')
		if(text.strip()=="SETUP"):
			y=input("Enter keywords.txt file path: \n").strip("\"")
			x=input("Enter functions.txt file path: \n").strip("\"")
			print("Please restart mushroom")
			with open(path+"\\directory.txt", "w") as a:
				a.write(x+"\n"+y)

		if(text.strip()=="ADD TO PATH"):
			print("Run the following command on your command promt, run the command promt as an admin")
			pyperclip.copy("setx /M PATH \"%PATH%;"+path+"\"")
			print("setx /M PATH \"%PATH%;"+path+"\"")
			print("copied to clipboard")

		if(text.strip()=="TRANSLATE"):
			with open(input("Enter Code File Path: \n").strip("\""), "r") as a:
				script00 = a.read()
			with open(input("Enter keywords.txt File Path:\n").strip("\""), "r") as b:
				script1 = b.read().split()
			with open(input("Enter functions.txt File Path:\n").strip("\""), "r") as c:
				script2 = c.read().split()


			script00 = script00.replace(script1[0], 'VAR' )
			script00 = script00.replace( script1[1], 'AND')
			script00 = script00.replace(script1[2],'OR' )
			script00 = script00.replace( script1[3],'NOT')
			script00 = script00.replace(script1[4],'IF' )
			script00 = script00.replace(script1[5],'ELIF' )
			script00 = script00.replace(script1[6],'ELSE' )
			script00 = script00.replace(script1[7],'FOR' )
			script00 = script00.replace(script1[8],'TO' )
			script00 = script00.replace(script1[9],'STEP' )
			script00 = script00.replace(script1[10],'WHILE' )
			script00 = script00.replace(script1[11],'FUN' )
			script00 = script00.replace( script1[12],'THEN')
			script00 = script00.replace(script1[13],'END' )
			script00 = script00.replace(script1[14],'RETURN' )
			script00 = script00.replace(script1[15],'CONTINUE' )
			script00 = script00.replace(script1[16],'BREAK' )


			script00 = script00.replace(script2[0],'NULL' )
			script00 = script00.replace(script2[1],'FALSE' )
			script00 = script00.replace( script2[2],'TRUE')
			script00 = script00.replace(script2[3],'MATH_PI' )
			script00 = script00.replace(script2[5],'PRINT_RET' )
			script00 = script00.replace(script2[4],'PRINT' )
			script00 = script00.replace(script2[7],'INPUT_INT' )
			script00 = script00.replace(script2[6],'INPUT' )
			script00 = script00.replace(script2[8],'CLEAR' )
			script00 = script00.replace(script2[9],'CLS' )
			script00 = script00.replace(script2[10],'IS_NUM' )
			script00 = script00.replace(script2[11],'IS_STR' )
			script00 = script00.replace(script2[12],'IS_LIST' )
			script00 = script00.replace(script2[13],'IS_FUN' )
			script00 = script00.replace(script2[14],'APPEND' )
			script00 = script00.replace( script2[15],'POP')
			script00 = script00.replace(script2[16],'EXTEND' )
			script00 = script00.replace(script2[17],'LEN' )

			print("TRANSLATION COMPLETE \n")
			save_path = input("Enter Destination File Location: \n(the translation will be saved under this location)\n").strip("\"")
			filename = input("Enter Destination File Name: \n")
			completeName = os.path.join(save_path, filename+".mush")         
			file = open(completeName, "w")
			file.write(script00)
			file.close()
			a.close
			b.close
			c.close

		if(text.strip()=="VSCODE"):
			with open('jsonTemplate.txt', 'r') as file00 :
				script000 = file00.read()

			with open(input("Enter keywords.txt File Path: \n").strip("\""), "r") as b:
				script01 = b.read().split()
			with open(input("Enter functions.txt File Path: \n").strip("\""), "r") as c:
				script02 = c.read().split()

			script000 = script000.replace('VAR', script01[0])
			script000 = script000.replace('AND', script01[1])
			script000 = script000.replace('OR', script01[2])
			script000 = script000.replace('NOT', script01[3])
			script000 = script000.replace('IF', script01[4])
			script000 = script000.replace('ELIF', script01[5])
			script000 = script000.replace('ELSE', script01[6])
			script000 = script000.replace('FOR', script01[7])
			script000 = script000.replace('TO', script01[8])
			script000 = script000.replace('STEP', script01[9])
			script000 = script000.replace('WHILE', script01[10])
			script000 = script000.replace('FUN', script01[11])
			script000 = script000.replace('THEN', script01[12])
			script000 = script000.replace('END', script01[13])
			script000 = script000.replace('RETURN', script01[14])
			script000 = script000.replace('CONTINUE', script01[15])
			script000 = script000.replace('BREAK', script01[16])

			script000 = script000.replace('NULL', script02[0])
			script000 = script000.replace('FALSE', script02[1])
			script000 = script000.replace('TRUE', script02[2])
			script000 = script000.replace('MATH_PI', script02[3])
			script000 = script000.replace('PRINT_RET', script02[5])
			script000 = script000.replace('PRINT', script02[4])
			script000 = script000.replace('INPUT_INT', script02[7])
			script000 = script000.replace('INPUT', script02[6])
			script000 = script000.replace('CLEAR', script02[8])
			script000 = script000.replace('CLS', script02[9])
			script000 = script000.replace('IS_NUM', script02[10])
			script000 = script000.replace('IS_STR', script02[11])
			script000 = script000.replace('IS_LIST', script02[12])
			script000 = script000.replace('IS_FUN', script02[13])
			script000 = script000.replace('APPEND', script02[14])
			script000 = script000.replace('POP', script02[15])
			script000 = script000.replace('EXTEND', script02[16])
			script000 = script000.replace('LEN', script02[17])



			b.close
			c.close
			file00.close
			with open(input("Enter mush.tmLanguage.json File Path: \n(located in Users>User>.vscode>extensions>k.berkboz.mushroom-0.0.1>.syntaxes>)\n").strip("\""), 'w') as file00 :
				file00.write(script000)
			file00.close


		if(text.strip()=="RUN"):
			script=[]
			with open(input("Enter File Path:").strip("\""), "r") as a:
				script = a.readlines()
			with open(path+"\\scriptload.txt", "w") as z:
				for item in script:
					z.write(item)
				z.close
			os.chdir(path)
			result, error = mushroom_script.run('<stdin>','RUN("scriptload.txt")')

			if error:
				print(error.as_string())
			elif result:
				if len(result.elements) == 1:
					print(repr(result.elements[0]))
				else:
					print(repr(result))

		if text.strip() == "": continue
		if(text.strip()!="SETUP" and text.strip()!="ADD TO PATH" and text.strip()!="RUN"and text.strip()!="TRANSLATE"and text.strip()!="VSCODE"):
			result, error = mushroom_script.run('<stdin>', text)

			if error:
				print(error.as_string())
			elif result:
				if len(result.elements) == 1:
					print(repr(result.elements[0]))
				else:
					print(repr(result))