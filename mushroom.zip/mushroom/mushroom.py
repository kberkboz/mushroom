import os

path=os.path.dirname(os.path.abspath(__file__))

with open (path+"\\directory.txt", "r") as a:
	directorylist= a.readlines()
	directorylist = [line.rstrip() for line in directorylist]

a.close
if directorylist[-1]=="openedOnce=FALSE":
	with open(path+"\\directory.txt", "w") as a:
		a.write(path+"\\functions.txt""\n"+path+"\\keywords.txt")
	a.close
import mushroom_script
import pyperclip

while True:
	print("")
	print("█▀▄▀█ █ █ █▀ █ █ █▀█ █▀█ █▀█ █▀▄▀█")
	print("█ ▀ █ █▄█ ▄█ █▀█ █▀▄ █▄█ █▄█ █ ▀ █")
	print("version 2.0")
	print("")
	print("by kberkboz")
	print("Spread the spores!")
	
	


	while True:

		text = input('mushroom > ')
		if(text.strip()=="SETUP"):
			y=input("Enter keywords.txt file path: \n").strip("\"")
			x=input("Enter functions.txt file path: \n").strip("\"")
			print("Please restart mushroom")
			with open(path+"\\directory.txt", "w") as a:
				a.write(x+"\n"+y)

		if(text.strip()=="ADD TO PATH"):
			print("Run the following command on your command promt, run the command promt as an admin")
			pyperclip.copy("setx /M PATH \"%PATH%;"+path+"\"")
			print("setx /M PATH \"%PATH%;"+path+"\"")
			print("copied to clipboard")

		if(text.strip()=="TRANSLATE"):
			with open(input("Enter Code File Path: \n").strip("\""), "r") as a:
				script00 = a.read()
			with open(input("Enter keywords.txt File Path:\n").strip("\""), "r") as b:
				keywords = b.read().split()
			with open(input("Enter functions.txt File Path:\n").strip("\""), "r") as c:
				functions = c.read().split()


			script00 = script00.replace(keywords[0], 'VAR' )
			script00 = script00.replace( keywords[1], 'AND')
			script00 = script00.replace(keywords[2],'OR' )
			script00 = script00.replace( keywords[3],'NOT')
			script00 = script00.replace(keywords[4],'IF' )
			script00 = script00.replace(keywords[5],'ELIF' )
			script00 = script00.replace(keywords[6],'ELSE' )
			script00 = script00.replace(keywords[7],'FOR' )
			script00 = script00.replace(keywords[8],'TO' )
			script00 = script00.replace(keywords[9],'STEP' )
			script00 = script00.replace(keywords[10],'WHILE' )
			script00 = script00.replace(keywords[11],'FUN' )
			script00 = script00.replace( keywords[12],'THEN')
			script00 = script00.replace(keywords[13],'END' )
			script00 = script00.replace(keywords[14],'RETURN' )
			script00 = script00.replace(keywords[15],'CONTINUE' )
			script00 = script00.replace(keywords[16],'BREAK' )


			script00 = script00.replace(keywords[17],'NULL' )
			script00 = script00.replace(keywords[18],'FALSE' )
			script00 = script00.replace( keywords[19],'TRUE')
			script00 = script00.replace(keywords[20],'MATH_PI' )
			script00 = script00.replace(functions[1],'PRINT_RET' )
			script00 = script00.replace(functions[0],'PRINT' )
			script00 = script00.replace(functions[3],'INPUT_INT' )
			script00 = script00.replace(functions[2],'INPUT' )
			script00 = script00.replace(functions[4],'CLEAR' )
			script00 = script00.replace(functions[5],'CLS' )
			script00 = script00.replace(functions[6],'IS_NUM' )
			script00 = script00.replace(functions[7],'IS_STR' )
			script00 = script00.replace(functions[8],'IS_LIST' )
			script00 = script00.replace(functions[9],'IS_FUN' )
			script00 = script00.replace(functions[10],'APPEND' )
			script00 = script00.replace( functions[11],'POP')
			script00 = script00.replace(functions[12],'EXTEND' )
			script00 = script00.replace(functions[13],'LEN' )

			print("TRANSLATION COMPLETE \n")
			save_path = input("Enter Destination File Location: \n(the translation will be saved under this location)\n").strip("\"")
			filename = input("Enter Destination File Name: \n")
			completeName = os.path.join(save_path, filename+".mush")         
			file = open(completeName, "w")
			file.write(script00)
			file.close()
			a.close
			b.close
			c.close

		if(text.strip()=="VSCODE"):
			with open('jsonTemplate.txt', 'r') as file00 :
				script000 = file00.read()

			with open(input("Enter keywords.txt File Path: \n").strip("\""), "r") as b:
				keywords0 = b.read().split()
			with open(input("Enter functions.txt File Path: \n").strip("\""), "r") as c:
				functions0 = c.read().split()

			script000 = script000.replace('VAR', keywords0[0])
			script000 = script000.replace('AND', keywords0[1])
			script000 = script000.replace('OR', keywords0[2])
			script000 = script000.replace('NOT', keywords0[3])
			script000 = script000.replace('IF', keywords0[4])
			script000 = script000.replace('ELIF', keywords0[5])
			script000 = script000.replace('ELSE', keywords0[6])
			script000 = script000.replace('FOR', keywords0[7])
			script000 = script000.replace('TO', keywords0[8])
			script000 = script000.replace('STEP', keywords0[9])
			script000 = script000.replace('WHILE', keywords0[10])
			script000 = script000.replace('FUN', keywords0[11])
			script000 = script000.replace('THEN', keywords0[12])
			script000 = script000.replace('END', keywords0[13])
			script000 = script000.replace('RETURN', keywords0[14])
			script000 = script000.replace('CONTINUE', keywords0[15])
			script000 = script000.replace('BREAK', keywords0[16])

			script000 = script000.replace('NULL', keywords0[17])
			script000 = script000.replace('FALSE', keywords0[18])
			script000 = script000.replace('TRUE', keywords0[19])
			script000 = script000.replace('MATH_PI', keywords[20])
			script000 = script000.replace('PRINT_RET', functions0[1])
			script000 = script000.replace('PRINT', functions0[0])
			script000 = script000.replace('INPUT_INT', functions0[3])
			script000 = script000.replace('INPUT', functions0[2])
			script000 = script000.replace('CLEAR', functions0[4])
			script000 = script000.replace('CLS', functions0[5])
			script000 = script000.replace('IS_NUM', functions0[6])
			script000 = script000.replace('IS_STR', functions0[7])
			script000 = script000.replace('IS_LIST', functions0[8])
			script000 = script000.replace('IS_FUN', functions0[9])
			script000 = script000.replace('APPEND', functions0[10])
			script000 = script000.replace('POP', functions0[11])
			script000 = script000.replace('EXTEND', functions0[12])
			script000 = script000.replace('LEN', functions0[13])



			b.close
			c.close
			file00.close
			with open(input("Enter mush.tmLanguage.json File Path: \n(located in Users>User>.vscode>extensions>k.berkboz.mushroom-0.0.1>.syntaxes>)\n").strip("\""), 'w') as file00 :
				file00.write(script000)
			file00.close


		if(text.strip()=="RUN"):
			script=[]
			with open(input("Enter File Path:").strip("\""), "r") as a:
				script = a.readlines()
			with open(path+"\\scriptload.txt", "w") as z:
				for item in script:
					z.write(item)
				z.close
			os.chdir(path)
			result, error = mushroom_script.run('<stdin>','RUN("scriptload.txt")')

			if error:
				print(error.as_string())
			elif result:
				if len(result.elements) == 1:
					print(repr(result.elements[0]))
				else:
					print(repr(result))

		if text.strip() == "": continue
		if(text.strip()!="SETUP" and text.strip()!="ADD TO PATH" and text.strip()!="RUN"and text.strip()!="TRANSLATE"and text.strip()!="VSCODE"):
			result, error = mushroom_script.run('<stdin>', text)

			if error:
				print(error.as_string())
			elif result:
				if len(result.elements) == 1:
					print(repr(result.elements[0]))
				else:
					print(repr(result))